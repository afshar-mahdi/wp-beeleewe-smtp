<?php

/**
 * Removes all Beeleewe SMTP data (including the saved SMTP password) when the plugin is deleted.
 */

if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

function bwsmtp_uninstall_site()
{
    delete_option('bwsmtp_options');
    delete_option('bwsmtp_auto_encryption_key'); // Legacy key from versions <= 1.0.0.
    delete_option('bwsmtp_config_method');
    delete_option('bwsmtp_db_version');
    delete_option('bwsmtp_last_error');
    delete_transient('bwsmtp_activation_redirect');
    delete_transient('bwsmtp_temp_password_choice');
    delete_transient('bwsmtp_temp_openssl_status');
}

if (is_multisite()) {
    foreach (get_sites(['fields' => 'ids', 'number' => 0]) as $blog_id) {
        switch_to_blog($blog_id);
        bwsmtp_uninstall_site();
        restore_current_blog();
    }
} else {
    bwsmtp_uninstall_site();
}
