<?php

/**
 * Plugin Name:       Beeleewe SMTP
 * Plugin URI:        https://beeleewe.com/wordpress/extention/smtp
 * Description:       Configures WordPress to send emails via your SMTP service using PHPMailer, with encrypted password storage.
 * Version:           1.1.0
 * Author:            Beeleewe
 * Author URI:        https://beeleewe.com
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       beeleewe-smtp
 * Domain Path:       /languages
 * Requires at least: 5.5
 * Requires PHP:      7.4
 */

// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit;
}

use PHPMailer\PHPMailer\PHPMailer;

// --- Constants ---
define('BWSMTP_PLUGIN_VERSION', '1.1.0');
define('BWSMTP_PLUGIN_FILE', __FILE__);
define('BWSMTP_PLUGIN_PATH', plugin_dir_path(BWSMTP_PLUGIN_FILE));
define('BWSMTP_PLUGIN_URL', plugin_dir_url(BWSMTP_PLUGIN_FILE));
define('BWSMTP_OPTIONS_KEY', 'bwsmtp_options');
define('BWSMTP_AUTO_KEY_OPTION', 'bwsmtp_auto_encryption_key'); // Legacy (<= 1.0.0), only read during migration.
define('BWSMTP_CONFIG_METHOD_OPTION', 'bwsmtp_config_method');
define('BWSMTP_DB_VERSION_OPTION', 'bwsmtp_db_version');
define('BWSMTP_LAST_ERROR_OPTION', 'bwsmtp_last_error');
define('BWSMTP_LEGACY_CIPHER', 'aes-256-cbc');
define('BWSMTP_WIZARD_SLUG', 'beeleewe-smtp-setup');
define('BWSMTP_SETTINGS_SLUG', 'beeleewe_smtp_settings');


/* ==========================================================================
 * Options helpers
 * ======================================================================== */

/** Default options. */
function bwsmtp_get_default_options()
{
    return [
        'host'            => '',
        'connection_type' => 'tls_587',
        'port'            => '',
        'user'            => '',
        'password'        => '',
        'charset'         => 'UTF-8',
        'from_email'      => '',
        'from_name'       => '',
        'force_from'      => false,
        'auto_tls'        => true,
        'timeout'         => 15,
        'debug_log'       => false,
    ];
}

/** Effective options (database values overridden by wp-config.php constants). */
function bwsmtp_get_effective_options()
{
    $defaults = bwsmtp_get_default_options();
    $options  = wp_parse_args((array) get_option(BWSMTP_OPTIONS_KEY, $defaults), $defaults);

    if (defined('BWSMTP_HOST'))            $options['host']            = (string) BWSMTP_HOST;
    if (defined('BWSMTP_USER'))            $options['user']            = (string) BWSMTP_USER;
    if (defined('BWSMTP_CONNECTION_TYPE')) $options['connection_type'] = (string) BWSMTP_CONNECTION_TYPE;
    if (defined('BWSMTP_PORT'))            $options['port']            = BWSMTP_PORT;
    if (defined('BWSMTP_CHARSET'))         $options['charset']         = (string) BWSMTP_CHARSET;
    if (defined('BWSMTP_FROM_EMAIL'))      $options['from_email']      = (string) BWSMTP_FROM_EMAIL;
    if (defined('BWSMTP_FROM_NAME'))       $options['from_name']       = (string) BWSMTP_FROM_NAME;
    if (defined('BWSMTP_FORCE_FROM'))      $options['force_from']      = (bool) BWSMTP_FORCE_FROM;
    if (defined('BWSMTP_TIMEOUT'))         $options['timeout']         = BWSMTP_TIMEOUT;
    if (defined('BWSMTP_DEBUG_LOG') && BWSMTP_DEBUG_LOG) $options['debug_log'] = true;

    $options['timeout'] = min(120, max(5, absint($options['timeout'])));
    return $options;
}

/** Resolve port + encryption from connection type and optional custom port. */
function bwsmtp_resolve_transport(array $options)
{
    $map  = [
        'tls_587'  => [587, 'tls'],
        'ssl_465'  => [465, 'ssl'],
        'none_25'  => [25, 'none'],
    ];
    $type = isset($map[$options['connection_type']]) ? $options['connection_type'] : 'tls_587';
    list($port, $encryption) = $map[$type];

    $custom = absint($options['port']);
    if ($custom >= 1 && $custom <= 65535) {
        $port = $custom;
    }
    return [$port, $encryption];
}


/* ==========================================================================
 * Password encryption (v2: key derived from wp-config.php salts)
 * ======================================================================== */

/** Binary 32-byte key derived from the site's AUTH salts. Never stored in the database by this plugin. */
function bwsmtp_crypto_key()
{
    return hash_hkdf('sha256', wp_salt('auth'), 32, 'beeleewe-smtp-password-v2');
}

/** True when this server can encrypt the password. */
function bwsmtp_encryption_available()
{
    if (function_exists('sodium_crypto_secretbox') && function_exists('sodium_crypto_secretbox_open')) {
        return true;
    }
    return function_exists('openssl_encrypt') && in_array('aes-256-gcm', openssl_get_cipher_methods(), true);
}

/** Does this stored value use the v2 format? */
function bwsmtp_is_v2_value($value)
{
    return is_string($value) && (strpos($value, 'v2s:') === 0 || strpos($value, 'v2g:') === 0);
}

/** Encrypt (authenticated). Returns a prefixed string or false. */
function bwsmtp_encrypt($value)
{
    if (!is_string($value) || $value === '') {
        return false;
    }
    try {
        $key = bwsmtp_crypto_key();
        if (function_exists('sodium_crypto_secretbox')) {
            $nonce = random_bytes(24);
            return 'v2s:' . base64_encode($nonce . sodium_crypto_secretbox($value, $nonce, $key));
        }
        if (function_exists('openssl_encrypt') && in_array('aes-256-gcm', openssl_get_cipher_methods(), true)) {
            $iv  = random_bytes(12);
            $tag = '';
            $ct  = openssl_encrypt($value, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag, '', 16);
            if ($ct === false || strlen($tag) !== 16) {
                return false;
            }
            return 'v2g:' . base64_encode($iv . $tag . $ct);
        }
    } catch (\Exception $e) {
        return false;
    }
    return false;
}

/** Decrypt a v2 value. Returns the plain text or false (wrong key / tampered / unsupported). */
function bwsmtp_decrypt($stored)
{
    if (!bwsmtp_is_v2_value($stored)) {
        return false;
    }
    $raw = base64_decode(substr($stored, 4), true);
    if ($raw === false) {
        return false;
    }
    $key = bwsmtp_crypto_key();

    if (strpos($stored, 'v2s:') === 0) {
        if (!function_exists('sodium_crypto_secretbox_open') || strlen($raw) < 24 + 16) {
            return false;
        }
        return sodium_crypto_secretbox_open(substr($raw, 24), substr($raw, 0, 24), $key);
    }

    if (!function_exists('openssl_decrypt') || strlen($raw) < 12 + 16 + 1) {
        return false;
    }
    return openssl_decrypt(substr($raw, 28), 'aes-256-gcm', $key, OPENSSL_RAW_DATA, substr($raw, 0, 12), substr($raw, 12, 16));
}

/** Legacy (<= 1.0.0) auto-key stored in the database. */
function bwsmtp_get_legacy_key()
{
    $key = get_option(BWSMTP_AUTO_KEY_OPTION, false);
    return (is_string($key) && $key !== '') ? $key : false;
}

/** Legacy AES-256-CBC decrypt, used only to migrate old installs. */
function bwsmtp_decrypt_legacy($encrypted_value)
{
    $key = bwsmtp_get_legacy_key();
    if ($key === false || $encrypted_value === '' || !function_exists('openssl_decrypt')) {
        return false;
    }
    $data   = base64_decode($encrypted_value, true);
    $iv_len = openssl_cipher_iv_length(BWSMTP_LEGACY_CIPHER);
    if ($data === false || $iv_len === false || strlen($data) <= $iv_len) {
        return false;
    }
    return openssl_decrypt(substr($data, $iv_len), BWSMTP_LEGACY_CIPHER, $key, OPENSSL_RAW_DATA, substr($data, 0, $iv_len));
}

/**
 * Turn the stored password value into plain text.
 * Returns ['value' => string|null, 'error' => string|null].
 */
function bwsmtp_resolve_stored_password($stored)
{
    if (!is_string($stored) || $stored === '') {
        return ['value' => null, 'error' => null];
    }
    if (bwsmtp_is_v2_value($stored)) {
        $plain = bwsmtp_decrypt($stored);
        if ($plain === false) {
            return ['value' => null, 'error' => __('The saved SMTP password could not be decrypted. This happens when the security keys (salts) in wp-config.php changed or the database was moved to another site. Please enter the password again in the settings.', 'beeleewe-smtp')];
        }
        return ['value' => $plain, 'error' => null];
    }
    // Unprefixed: either a legacy auto-key ciphertext or a plain-text password.
    $method = get_option(BWSMTP_CONFIG_METHOD_OPTION, 'manual');
    if ($method !== 'plaintext' && bwsmtp_get_legacy_key() !== false) {
        $plain = bwsmtp_decrypt_legacy($stored);
        if ($plain === false) {
            return ['value' => null, 'error' => __('The saved SMTP password could not be decrypted. Please enter the password again in the settings.', 'beeleewe-smtp')];
        }
        return ['value' => $plain, 'error' => null];
    }
    return ['value' => $stored, 'error' => null];
}

/** Plain-text SMTP password (constant first, then database). */
function bwsmtp_get_password()
{
    if (defined('BWSMTP_PASSWORD')) {
        return ['value' => (string) BWSMTP_PASSWORD, 'error' => null];
    }
    $options = (array) get_option(BWSMTP_OPTIONS_KEY, []);
    return bwsmtp_resolve_stored_password(isset($options['password']) ? $options['password'] : '');
}

/** Where is the password kept? 'constants_pass' | 'encrypted' | 'plaintext' | 'none'. */
function bwsmtp_storage_status()
{
    if (defined('BWSMTP_PASSWORD')) {
        return 'constants_pass';
    }
    $options = (array) get_option(BWSMTP_OPTIONS_KEY, []);
    $stored  = isset($options['password']) ? $options['password'] : '';
    if ($stored === '') {
        return 'none';
    }
    if (bwsmtp_is_v2_value($stored)) {
        return 'encrypted';
    }
    $method = get_option(BWSMTP_CONFIG_METHOD_OPTION, 'manual');
    return ($method !== 'plaintext' && bwsmtp_get_legacy_key() !== false) ? 'encrypted' : 'plaintext';
}


/* ==========================================================================
 * Errors shown to admins
 * ======================================================================== */

/** Remember the last sending/config problem (no recipient or subject data). */
function bwsmtp_record_error($message)
{
    $message = wp_strip_all_tags((string) $message);
    $message = function_exists('mb_substr') ? mb_substr($message, 0, 500) : substr($message, 0, 500);
    $current = get_option(BWSMTP_LAST_ERROR_OPTION, false);
    if (is_array($current) && isset($current['message'], $current['time'])
        && $current['message'] === $message && (time() - (int) $current['time']) < HOUR_IN_SECONDS) {
        return; // Avoid a database write on every failed mail.
    }
    update_option(BWSMTP_LAST_ERROR_OPTION, ['time' => time(), 'message' => $message], false);
}

add_action('admin_notices', function () {
    if (!current_user_can('manage_options')) {
        return;
    }
    $screen = function_exists('get_current_screen') ? get_current_screen() : null;
    if (!$screen || !in_array($screen->id, ['dashboard', 'plugins', 'settings_page_' . BWSMTP_SETTINGS_SLUG], true)) {
        return;
    }
    $error = get_option(BWSMTP_LAST_ERROR_OPTION, false);
    if (!is_array($error) || empty($error['message'])) {
        return;
    }
    echo '<div class="notice notice-error"><p><strong>' . esc_html__('Beeleewe SMTP:', 'beeleewe-smtp') . '</strong> ';
    echo esc_html($error['message']);
    echo ' <em>(' . esc_html(sprintf(
        /* translators: %s: human readable time difference, e.g. "5 minutes" */
        __('%s ago', 'beeleewe-smtp'),
        human_time_diff((int) $error['time'], time())
    )) . ')</em> ';
    echo '<a href="' . esc_url(admin_url('options-general.php?page=' . BWSMTP_SETTINGS_SLUG)) . '">' . esc_html__('Check settings', 'beeleewe-smtp') . '</a></p></div>';
});


/* ==========================================================================
 * Bootstrap: text domain, upgrade routine, activation
 * ======================================================================== */

add_action('init', function () {
    load_plugin_textdomain('beeleewe-smtp', false, dirname(plugin_basename(BWSMTP_PLUGIN_FILE)) . '/languages');
});

/** One-time upgrade: move legacy (DB auto-key) and plain-text passwords to the v2 format. */
add_action('plugins_loaded', function () {
    if (version_compare((string) get_option(BWSMTP_DB_VERSION_OPTION, '0'), BWSMTP_PLUGIN_VERSION, '>=')) {
        return;
    }
    $options = get_option(BWSMTP_OPTIONS_KEY, false);
    if (is_array($options)) {
        $stored = isset($options['password']) ? $options['password'] : '';
        if ($stored !== '' && !bwsmtp_is_v2_value($stored) && !defined('BWSMTP_PASSWORD') && bwsmtp_encryption_available()) {
            $resolved = bwsmtp_resolve_stored_password($stored);
            if ($resolved['value'] !== null) {
                $encrypted = bwsmtp_encrypt($resolved['value']);
                if ($encrypted !== false) {
                    $options['password'] = $encrypted;
                    update_option(BWSMTP_OPTIONS_KEY, $options, false);
                    update_option(BWSMTP_CONFIG_METHOD_OPTION, 'encrypted');
                    delete_option(BWSMTP_AUTO_KEY_OPTION); // Old key is no longer needed.
                }
            }
        } elseif ($stored === '' && bwsmtp_get_legacy_key() !== false) {
            delete_option(BWSMTP_AUTO_KEY_OPTION);
        }
        if (function_exists('wp_set_option_autoload')) {
            wp_set_option_autoload(BWSMTP_OPTIONS_KEY, false);
        }
    }
    update_option(BWSMTP_DB_VERSION_OPTION, BWSMTP_PLUGIN_VERSION, false);
});

register_activation_hook(BWSMTP_PLUGIN_FILE, function () {
    // Do NOT touch stored credentials here: deactivate/activate must be harmless.
    if (get_option(BWSMTP_OPTIONS_KEY) === false) {
        add_option(BWSMTP_OPTIONS_KEY, bwsmtp_get_default_options(), '', 'no');
    }
    $opts = (array) get_option(BWSMTP_OPTIONS_KEY, []);
    if (empty($opts['host']) && empty(get_option(BWSMTP_CONFIG_METHOD_OPTION))) {
        set_transient('bwsmtp_activation_redirect', true, 30);
    }
});

register_deactivation_hook(BWSMTP_PLUGIN_FILE, function () {
    delete_transient('bwsmtp_activation_redirect');
    delete_transient('bwsmtp_temp_password_choice');
});


/* ==========================================================================
 * Setup wizard
 * ======================================================================== */

/** Redirect to the wizard after a fresh activation. */
add_action('admin_init', function () {
    if (!get_transient('bwsmtp_activation_redirect')) {
        return;
    }
    delete_transient('bwsmtp_activation_redirect');
    if (isset($_GET['activate-multi']) || wp_doing_ajax() || is_network_admin()) {
        return;
    }
    $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';
    if (current_user_can('manage_options') && $page !== BWSMTP_WIZARD_SLUG && empty($_POST)) {
        wp_safe_redirect(admin_url('options-general.php?page=' . BWSMTP_WIZARD_SLUG));
        exit;
    }
});

/** Menu pages. */
add_action('admin_menu', function () {
    $wizard_title   = __('Beeleewe SMTP Setup', 'beeleewe-smtp');
    $settings_title = __('Beeleewe SMTP Settings', 'beeleewe-smtp');
    $menu_title     = __('Beeleewe SMTP', 'beeleewe-smtp');
    add_submenu_page(null, $wizard_title, $wizard_title, 'manage_options', BWSMTP_WIZARD_SLUG, 'bwsmtp_render_setup_wizard');
    add_options_page($settings_title, $menu_title, 'manage_options', BWSMTP_SETTINGS_SLUG, 'bwsmtp_settings_page_html');
});

/** Holds the last submitted wizard values so they can be re-displayed after a validation error. */
function bwsmtp_wizard_old_input($set = null)
{
    static $old = null;
    if ($set !== null) {
        $old = $set;
    }
    return $old;
}

/** Render the wizard. */
function bwsmtp_render_setup_wizard()
{
    if (!current_user_can('manage_options')) {
        wp_die(esc_html__('You do not have sufficient permissions to access this page.', 'beeleewe-smtp'));
    }

    // "Restart" link.
    if (isset($_GET['bwsmtp_restart_nonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['bwsmtp_restart_nonce'])), 'bwsmtp_restart_wizard')) {
        delete_option(BWSMTP_CONFIG_METHOD_OPTION);
        delete_transient('bwsmtp_temp_password_choice');
        wp_safe_redirect(admin_url('options-general.php?page=' . BWSMTP_WIZARD_SLUG . '&step=1'));
        exit;
    }

    $step     = isset($_GET['step']) ? min(4, max(1, absint($_GET['step']))) : 1;
    $errors   = [];
    $verified = false;

    if ($step > 1 && isset($_POST['bwsmtp_wizard_nonce'])) {
        $nonce = sanitize_text_field(wp_unslash($_POST['bwsmtp_wizard_nonce']));
        if (!wp_verify_nonce($nonce, 'bwsmtp_wizard_step_' . ($step - 1))) {
            wp_die(esc_html__('Security check failed. Please try again.', 'beeleewe-smtp'), 403);
        }
        $verified = true;
        if (!bwsmtp_process_wizard_step($step - 1, wp_unslash($_POST))) {
            $step--;
            $errors = get_settings_errors('bwsmtp_wizard_options');
        }
    }
    if ($step > 1 && !$verified && !($step === 4 && get_option(BWSMTP_CONFIG_METHOD_OPTION))) {
        $step = 1; // Direct visits to later steps start over.
    }

    $encryption_ok = bwsmtp_encryption_available();
?>
    <div class="wrap bwsmtp-wizard">
        <h1><?php esc_html_e('Beeleewe SMTP Setup Wizard', 'beeleewe-smtp'); ?></h1>
        <?php if (!empty($errors)) : ?>
            <div id="message" class="error notice is-dismissible">
                <?php foreach ($errors as $error) : ?>
                    <p><strong><?php echo esc_html($error['message']); ?></strong></p>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <?php if ($step < 4) : ?>
            <form method="post" action="<?php echo esc_url(admin_url('options-general.php?page=' . BWSMTP_WIZARD_SLUG . '&step=' . ($step + 1))); ?>">
                <?php wp_nonce_field('bwsmtp_wizard_step_' . $step, 'bwsmtp_wizard_nonce'); ?>

                <?php if ($step === 1) : ?>
                    <h2><?php esc_html_e('Welcome!', 'beeleewe-smtp'); ?></h2>
                    <p><?php esc_html_e('This wizard will help you configure Beeleewe SMTP to improve email deliverability.', 'beeleewe-smtp'); ?></p>
                    <?php if ($encryption_ok) : ?>
                        <p style="color:green;">&#x2714; <?php esc_html_e('Secure password encryption is available on this server.', 'beeleewe-smtp'); ?></p>
                    <?php else : ?>
                        <p style="color:orange;">&#x26A0; <?php esc_html_e('Password encryption is not available on your server. Passwords saved via the UI will be stored as plain text.', 'beeleewe-smtp'); ?></p>
                    <?php endif; ?>
                    <p class="submit"><button type="submit" name="submit" class="button button-primary"><?php esc_html_e("Let's Go!", 'beeleewe-smtp'); ?> &rarr;</button></p>

                <?php elseif ($step === 2) : ?>
                    <h2><?php esc_html_e('Password Security Method', 'beeleewe-smtp'); ?></h2>
                    <p><?php esc_html_e('For the highest password security, define only your SMTP password in your wp-config.php file using a constant named BWSMTP_PASSWORD. This keeps your most sensitive credential out of the database.', 'beeleewe-smtp'); ?></p>
                    <p><strong><?php esc_html_e('Are you able and willing to add the BWSMTP_PASSWORD constant to your wp-config.php file?', 'beeleewe-smtp'); ?></strong></p>
                    <fieldset>
                        <label><input type="radio" name="password_method_choice" value="constants" required> <?php esc_html_e('Yes, I will define BWSMTP_PASSWORD in wp-config.php (Most Secure for Password)', 'beeleewe-smtp'); ?></label><br>
                        <label><input type="radio" name="password_method_choice" value="ui" required> <?php esc_html_e('No, I prefer to enter the password on the next screen (Stored in Database)', 'beeleewe-smtp'); ?></label>
                    </fieldset>
                    <p class="submit"><button type="submit" name="submit" class="button button-primary"><?php esc_html_e('Next Step', 'beeleewe-smtp'); ?> &rarr;</button></p>

                <?php elseif ($step === 3) : ?>
                    <?php $choice = get_transient('bwsmtp_temp_password_choice') ?: 'ui'; ?>
                    <h2><?php esc_html_e('Enter SMTP Details', 'beeleewe-smtp'); ?></h2>
                    <?php if ($choice === 'constants') : ?>
                        <p><?php esc_html_e('Please add the following line to your wp-config.php file (replacing the placeholder):', 'beeleewe-smtp'); ?></p>
                        <pre style="background:#eee; padding:10px; border:1px solid #ccc; overflow-x:auto;"><code><?php echo esc_html("define('BWSMTP_PASSWORD', 'your_smtp_password');"); ?></code></pre>
                        <p><?php esc_html_e('Now fill in the rest of your SMTP details below. These will be saved in the database.', 'beeleewe-smtp'); ?></p>
                    <?php elseif ($encryption_ok) : ?>
                        <p><?php esc_html_e('Your password will be encrypted before it is saved. The encryption key is derived from the security keys in your wp-config.php, so a database leak alone does not expose it.', 'beeleewe-smtp'); ?></p>
                    <?php else : ?>
                        <p style="color:red;"><strong><?php esc_html_e('Warning: encryption is not available. Your password will be stored as plain text in the database.', 'beeleewe-smtp'); ?></strong></p>
                    <?php endif; ?>
                    <table class="form-table" role="presentation">
                        <tbody>
                            <tr><th scope="row"><label for="bwsmtp_host"><?php esc_html_e('SMTP Host', 'beeleewe-smtp'); ?></label></th><td><?php bwsmtp_field_host_html(true); ?></td></tr>
                            <tr><th scope="row"><?php esc_html_e('Connection Type', 'beeleewe-smtp'); ?></th><td><?php bwsmtp_field_connection_type_html(true); ?></td></tr>
                            <tr><th scope="row"><label for="bwsmtp_user"><?php esc_html_e('SMTP Username', 'beeleewe-smtp'); ?></label></th><td><?php bwsmtp_field_user_html(true); ?></td></tr>
                            <?php if ($choice === 'ui') : ?>
                                <tr><th scope="row"><label for="bwsmtp_password"><?php esc_html_e('SMTP Password', 'beeleewe-smtp'); ?></label></th><td><?php bwsmtp_field_password_html(true); ?></td></tr>
                            <?php endif; ?>
                            <tr><th scope="row"><label for="bwsmtp_from_email"><?php esc_html_e('From Email', 'beeleewe-smtp'); ?></label></th><td><?php bwsmtp_field_from_email_html(true); ?></td></tr>
                            <tr><th scope="row"><label for="bwsmtp_from_name"><?php esc_html_e('From Name', 'beeleewe-smtp'); ?></label></th><td><?php bwsmtp_field_from_name_html(true); ?></td></tr>
                            <tr><th scope="row"><label for="bwsmtp_charset"><?php esc_html_e('Email Charset', 'beeleewe-smtp'); ?></label></th><td><?php bwsmtp_field_charset_html(true); ?></td></tr>
                        </tbody>
                    </table>
                    <input type="hidden" name="password_method_choice_final" value="<?php echo esc_attr($choice); ?>">
                    <p class="submit"><button type="submit" name="submit" class="button button-primary"><?php esc_html_e('Save and Complete Setup', 'beeleewe-smtp'); ?> &rarr;</button></p>
                <?php endif; ?>
            </form>

        <?php else : ?>
            <h2><?php esc_html_e('Setup Complete!', 'beeleewe-smtp'); ?></h2>
            <?php
            $status = bwsmtp_storage_status();
            if ($status === 'constants_pass') {
                echo '<p style="color:green;">&#x2714; ' . esc_html__('Beeleewe SMTP configured! Settings saved to the database; the password is read from your wp-config.php file.', 'beeleewe-smtp') . '</p>';
            } elseif ($status === 'encrypted') {
                echo '<p style="color:green;">&#x2714; ' . esc_html__('Beeleewe SMTP configuration saved. Password is stored encrypted.', 'beeleewe-smtp') . '</p>';
            } elseif ($status === 'plaintext') {
                echo '<p style="color:orange;">&#x26A0; ' . esc_html__('Beeleewe SMTP configuration saved. Warning: password stored as plain text in the database.', 'beeleewe-smtp') . '</p>';
            } else {
                echo '<p>' . esc_html__('Beeleewe SMTP configuration saved.', 'beeleewe-smtp') . '</p>';
            }
            delete_transient('bwsmtp_temp_password_choice');
            ?>
            <p><?php esc_html_e('We recommend sending a test email to ensure your settings are correct.', 'beeleewe-smtp'); ?></p>
            <p>
                <a href="<?php echo esc_url(admin_url('options-general.php?page=' . BWSMTP_SETTINGS_SLUG)); ?>" class="button button-primary"><?php esc_html_e('View Settings', 'beeleewe-smtp'); ?></a>
                <a href="<?php echo esc_url(wp_nonce_url(admin_url('options-general.php?page=' . BWSMTP_WIZARD_SLUG . '&step=1'), 'bwsmtp_restart_wizard', 'bwsmtp_restart_nonce')); ?>" class="button button-secondary"><?php esc_html_e('Restart Setup', 'beeleewe-smtp'); ?></a>
            </p>
        <?php endif; ?>
    </div>
<?php
}

/** Process one wizard step. $post_data must already be unslashed. */
function bwsmtp_process_wizard_step($step, $post_data)
{
    $post_data = is_array($post_data) ? $post_data : [];

    if ($step === 2) {
        $choice = (isset($post_data['password_method_choice']) && $post_data['password_method_choice'] === 'constants') ? 'constants' : 'ui';
        set_transient('bwsmtp_temp_password_choice', $choice, HOUR_IN_SECONDS);
        if ($choice === 'constants') {
            update_option(BWSMTP_CONFIG_METHOD_OPTION, 'constants_pass');
        }
        return true;
    }

    if ($step === 3) {
        $choice    = (isset($post_data['password_method_choice_final']) && $post_data['password_method_choice_final'] === 'constants') ? 'constants' : 'ui';
        $submitted = (isset($post_data[BWSMTP_OPTIONS_KEY]) && is_array($post_data[BWSMTP_OPTIONS_KEY])) ? $post_data[BWSMTP_OPTIONS_KEY] : [];
        $current   = wp_parse_args((array) get_option(BWSMTP_OPTIONS_KEY, []), bwsmtp_get_default_options());

        $result = bwsmtp_build_options($submitted, $current, 'bwsmtp_wizard_options', $choice === 'constants');
        if ($result === false) {
            bwsmtp_wizard_old_input($submitted);
            return false;
        }
        update_option(BWSMTP_OPTIONS_KEY, $result['options'], false);
        update_option(BWSMTP_CONFIG_METHOD_OPTION, $result['method']);
        delete_option(BWSMTP_LAST_ERROR_OPTION);
    }
    return true;
}


/* ==========================================================================
 * Shared validation / sanitising (wizard + settings page)
 * ======================================================================== */

/**
 * Validate submitted values and build the options array to save.
 * Fields missing from $input keep their current value.
 *
 * @param array  $input            Unslashed submitted values.
 * @param array  $current          Currently saved options (with defaults).
 * @param string $error_group      Settings-error group for validation messages.
 * @param bool   $password_in_const True when the password lives in wp-config.php.
 * @return array|false ['options' => array, 'method' => string] or false on validation error.
 */
function bwsmtp_build_options(array $input, array $current, $error_group, $password_in_const = false)
{
    $errors = false;
    $fail   = function ($code, $message) use ($error_group, &$errors) {
        add_settings_error($error_group, $code, $message, 'error');
        $errors = true;
    };
    $has = function ($key) use ($input) {
        return array_key_exists($key, $input);
    };
    $text = function ($key) use ($input, $current, $has) {
        return $has($key) ? sanitize_text_field((string) $input[$key]) : $current[$key];
    };

    $out = $current;

    // Host (required).
    if (!defined('BWSMTP_HOST')) {
        $out['host'] = $text('host');
        if ($out['host'] === '') {
            $fail('host_required', __('SMTP Host is required.', 'beeleewe-smtp'));
        }
    }

    // Username (optional, any format: many providers use API keys or IDs, not email addresses).
    if (!defined('BWSMTP_USER')) {
        $out['user'] = $text('user');
    }

    // Connection type.
    if (!defined('BWSMTP_CONNECTION_TYPE')) {
        $allowed = ['tls_587', 'ssl_465', 'none_25'];
        if ($has('connection_type')) {
            $out['connection_type'] = in_array($input['connection_type'], $allowed, true) ? $input['connection_type'] : 'tls_587';
        }
    }

    // Custom port.
    if (!defined('BWSMTP_PORT') && $has('port')) {
        $port = trim((string) $input['port']);
        if ($port === '') {
            $out['port'] = '';
        } elseif (ctype_digit($port) && (int) $port >= 1 && (int) $port <= 65535) {
            $out['port'] = (string) (int) $port;
        } else {
            $fail('port_invalid', __('Custom port must be a number between 1 and 65535 (or empty).', 'beeleewe-smtp'));
        }
    }

    // Charset.
    if (!defined('BWSMTP_CHARSET') && $has('charset')) {
        $out['charset'] = in_array($input['charset'], ['UTF-8', 'ISO-8859-1'], true) ? $input['charset'] : 'UTF-8';
    }

    // From email / name.
    if (!defined('BWSMTP_FROM_EMAIL') && $has('from_email')) {
        $from = sanitize_email((string) $input['from_email']);
        if (trim((string) $input['from_email']) !== '' && !is_email($from)) {
            $fail('from_email_invalid', __('From Email is not a valid email address.', 'beeleewe-smtp'));
        } else {
            $out['from_email'] = $from;
        }
    }
    if (!defined('BWSMTP_FROM_NAME')) {
        $out['from_name'] = $text('from_name');
    }
    if (!defined('BWSMTP_FORCE_FROM') && $has('force_from')) {
        $out['force_from'] = !empty($input['force_from']);
    }

    // Auto TLS, timeout, debug.
    if ($has('auto_tls')) {
        $out['auto_tls'] = !empty($input['auto_tls']);
    }
    if (!defined('BWSMTP_TIMEOUT') && $has('timeout')) {
        $out['timeout'] = min(120, max(5, absint($input['timeout'])));
    }
    if (!(defined('BWSMTP_DEBUG_LOG') && BWSMTP_DEBUG_LOG) && $has('debug_log')) {
        $out['debug_log'] = !empty($input['debug_log']);
    }

    // Password: empty input KEEPS the saved password; the checkbox clears it.
    if (!defined('BWSMTP_PASSWORD') && !$password_in_const) {
        if (!empty($input['clear_password'])) {
            $out['password'] = '';
        } else {
            $new = isset($input['password']) ? trim((string) $input['password']) : '';
            if ($new !== '') {
                if (bwsmtp_encryption_available()) {
                    $encrypted = bwsmtp_encrypt($new);
                    if ($encrypted === false) {
                        $fail('encryption_failed', __('Failed to encrypt password. Password not saved.', 'beeleewe-smtp'));
                    } else {
                        $out['password'] = $encrypted;
                    }
                } else {
                    $out['password'] = $new; // Plain text: no encryption available on this server.
                }
            }
        }
    }

    if ($errors) {
        return false;
    }

    if ($password_in_const || defined('BWSMTP_PASSWORD')) {
        $method = 'constants_pass';
    } elseif (bwsmtp_is_v2_value($out['password'])) {
        $method = 'encrypted';
    } elseif ($out['password'] !== '') {
        $method = (bwsmtp_get_legacy_key() !== false && get_option(BWSMTP_CONFIG_METHOD_OPTION) !== 'plaintext') ? 'encrypted' : 'plaintext';
    } else {
        $method = bwsmtp_encryption_available() ? 'encrypted' : 'plaintext';
    }

    return ['options' => $out, 'method' => $method];
}


/* ==========================================================================
 * Regular settings page
 * ======================================================================== */

add_action('admin_init', function () {
    register_setting('beeleewe_smtp_settings_group', BWSMTP_OPTIONS_KEY, ['sanitize_callback' => 'bwsmtp_sanitize_options_manual']);

    add_settings_section('bwsmtp_section_credentials', __('SMTP Configuration', 'beeleewe-smtp'), 'bwsmtp_section_credentials_callback', BWSMTP_SETTINGS_SLUG);
    add_settings_field('bwsmtp_host', __('SMTP Host', 'beeleewe-smtp'), 'bwsmtp_field_host_html', BWSMTP_SETTINGS_SLUG, 'bwsmtp_section_credentials', ['label_for' => 'bwsmtp_host']);
    add_settings_field('bwsmtp_connection_type', __('Connection Type', 'beeleewe-smtp'), 'bwsmtp_field_connection_type_html', BWSMTP_SETTINGS_SLUG, 'bwsmtp_section_credentials');
    add_settings_field('bwsmtp_user', __('SMTP Username', 'beeleewe-smtp'), 'bwsmtp_field_user_html', BWSMTP_SETTINGS_SLUG, 'bwsmtp_section_credentials', ['label_for' => 'bwsmtp_user']);
    add_settings_field('bwsmtp_password', __('SMTP Password', 'beeleewe-smtp'), 'bwsmtp_field_password_html', BWSMTP_SETTINGS_SLUG, 'bwsmtp_section_credentials', ['label_for' => 'bwsmtp_password']);

    add_settings_section('bwsmtp_section_sender', __('Sender', 'beeleewe-smtp'), '__return_false', BWSMTP_SETTINGS_SLUG);
    add_settings_field('bwsmtp_from_email', __('From Email', 'beeleewe-smtp'), 'bwsmtp_field_from_email_html', BWSMTP_SETTINGS_SLUG, 'bwsmtp_section_sender', ['label_for' => 'bwsmtp_from_email']);
    add_settings_field('bwsmtp_from_name', __('From Name', 'beeleewe-smtp'), 'bwsmtp_field_from_name_html', BWSMTP_SETTINGS_SLUG, 'bwsmtp_section_sender', ['label_for' => 'bwsmtp_from_name']);
    add_settings_field('bwsmtp_force_from', __('Force From', 'beeleewe-smtp'), 'bwsmtp_field_force_from_html', BWSMTP_SETTINGS_SLUG, 'bwsmtp_section_sender');

    add_settings_section('bwsmtp_section_advanced', __('Advanced', 'beeleewe-smtp'), '__return_false', BWSMTP_SETTINGS_SLUG);
    add_settings_field('bwsmtp_port', __('Custom Port', 'beeleewe-smtp'), 'bwsmtp_field_port_html', BWSMTP_SETTINGS_SLUG, 'bwsmtp_section_advanced', ['label_for' => 'bwsmtp_port']);
    add_settings_field('bwsmtp_timeout', __('Timeout (seconds)', 'beeleewe-smtp'), 'bwsmtp_field_timeout_html', BWSMTP_SETTINGS_SLUG, 'bwsmtp_section_advanced', ['label_for' => 'bwsmtp_timeout']);
    add_settings_field('bwsmtp_auto_tls', __('Opportunistic TLS', 'beeleewe-smtp'), 'bwsmtp_field_auto_tls_html', BWSMTP_SETTINGS_SLUG, 'bwsmtp_section_advanced');
    add_settings_field('bwsmtp_charset', __('Email Charset', 'beeleewe-smtp'), 'bwsmtp_field_charset_html', BWSMTP_SETTINGS_SLUG, 'bwsmtp_section_advanced', ['label_for' => 'bwsmtp_charset']);
    add_settings_field('bwsmtp_debug_log', __('Debug Logging', 'beeleewe-smtp'), 'bwsmtp_field_debug_log_html', BWSMTP_SETTINGS_SLUG, 'bwsmtp_section_advanced', ['label_for' => 'bwsmtp_debug_log']);

    add_settings_section('bwsmtp_section_test', __('Send a Test Email', 'beeleewe-smtp'), 'bwsmtp_section_test_callback', BWSMTP_SETTINGS_SLUG);
    add_settings_field('bwsmtp_test_email_recipient', __('Send To', 'beeleewe-smtp'), 'bwsmtp_field_test_email_recipient_html', BWSMTP_SETTINGS_SLUG, 'bwsmtp_section_test', ['label_for' => 'bwsmtp_test_email_recipient']);
});

/** Sanitize callback for options.php (it already unslashes the input). */
function bwsmtp_sanitize_options_manual($input)
{
    $current = wp_parse_args((array) get_option(BWSMTP_OPTIONS_KEY, []), bwsmtp_get_default_options());
    $result  = bwsmtp_build_options(is_array($input) ? $input : [], $current, 'bwsmtp_options');
    if ($result === false) {
        return $current;
    }
    update_option(BWSMTP_CONFIG_METHOD_OPTION, $result['method']);
    delete_option(BWSMTP_LAST_ERROR_OPTION); // Settings changed: drop the stale error.
    return $result['options'];
}

function bwsmtp_section_credentials_callback($args)
{
    $status = bwsmtp_storage_status();
?>
    <p id="<?php echo esc_attr($args['id']); ?>-description">
        <?php esc_html_e('Configure your SMTP server details below.', 'beeleewe-smtp'); ?>
        <?php if ($status === 'constants_pass') : ?>
            <br><em><?php esc_html_e('Password source: defined in wp-config.php (BWSMTP_PASSWORD).', 'beeleewe-smtp'); ?></em>
        <?php elseif ($status === 'plaintext') : ?>
            <br><strong style="color:red;"><?php esc_html_e('Password storage: plain text (insecure). Re-save the password to encrypt it if your server supports it.', 'beeleewe-smtp'); ?></strong>
        <?php elseif ($status === 'encrypted') : ?>
            <br><em><?php esc_html_e('Password storage: encrypted.', 'beeleewe-smtp'); ?></em>
        <?php endif; ?>
    </p>
<?php
}

function bwsmtp_section_test_callback($args)
{
?>
    <p id="<?php echo esc_attr($args['id']); ?>-description"><?php esc_html_e('Enter an email address below and click "Send Test" to verify your saved SMTP settings.', 'beeleewe-smtp'); ?></p>
<?php
}

/** Values to show in a form field (wizard re-displays the last submission after an error). */
function bwsmtp_form_options($is_wizard)
{
    $options = bwsmtp_get_effective_options();
    if ($is_wizard) {
        $old = bwsmtp_wizard_old_input();
        if (is_array($old)) {
            foreach (['host', 'user', 'connection_type', 'charset', 'from_name'] as $k) {
                if (isset($old[$k])) {
                    $options[$k] = sanitize_text_field((string) $old[$k]);
                }
            }
            if (isset($old['from_email'])) {
                $options['from_email'] = sanitize_text_field((string) $old['from_email']);
            }
        }
    }
    return $options;
}

function bwsmtp_const_note($constant, $is_wizard)
{
    if (defined($constant) && !$is_wizard) {
        printf(' <em>' . esc_html__('Defined in wp-config.php (%s).', 'beeleewe-smtp') . '</em>', '<code>' . esc_html($constant) . '</code>');
    }
}

function bwsmtp_field_host_html($is_wizard = false)
{
    $options     = bwsmtp_form_options($is_wizard);
    $is_constant = defined('BWSMTP_HOST') && !$is_wizard;
?>
    <input type="text" id="bwsmtp_host" name="<?php echo esc_attr(BWSMTP_OPTIONS_KEY); ?>[host]" value="<?php echo esc_attr($options['host']); ?>" class="regular-text" placeholder="<?php esc_attr_e('e.g., mail.your-domain.com', 'beeleewe-smtp'); ?>" required <?php disabled($is_constant); ?>>
    <p class="description"><?php esc_html_e('Hostname or IP address of your SMTP server.', 'beeleewe-smtp'); ?> (<?php esc_html_e('Required', 'beeleewe-smtp'); ?>)<?php bwsmtp_const_note('BWSMTP_HOST', $is_wizard); ?></p>
<?php
}

function bwsmtp_field_connection_type_html($is_wizard = false)
{
    $options     = bwsmtp_form_options($is_wizard);
    $is_constant = defined('BWSMTP_CONNECTION_TYPE') && !$is_wizard;
    $types       = [
        'tls_587' => __('TLS - Port 587 (Recommended)', 'beeleewe-smtp'),
        'ssl_465' => __('SSL - Port 465', 'beeleewe-smtp'),
        'none_25' => __('None - Port 25 (Unencrypted - Not Recommended)', 'beeleewe-smtp'),
    ];
?>
    <fieldset>
        <legend class="screen-reader-text"><span><?php esc_html_e('Connection Type (Encryption & Port)', 'beeleewe-smtp'); ?></span></legend>
        <?php foreach ($types as $value => $label) : ?>
            <label><input type="radio" name="<?php echo esc_attr(BWSMTP_OPTIONS_KEY); ?>[connection_type]" value="<?php echo esc_attr($value); ?>" <?php checked($options['connection_type'], $value); ?> <?php disabled($is_constant); ?>> <?php echo esc_html($label); ?></label><br>
        <?php endforeach; ?>
    </fieldset>
    <p class="description"><?php esc_html_e('Select the encryption and port combination required by your SMTP provider.', 'beeleewe-smtp'); ?><?php bwsmtp_const_note('BWSMTP_CONNECTION_TYPE', $is_wizard); ?></p>
<?php
}

function bwsmtp_field_user_html($is_wizard = false)
{
    $options     = bwsmtp_form_options($is_wizard);
    $is_constant = defined('BWSMTP_USER') && !$is_wizard;
?>
    <input type="text" id="bwsmtp_user" name="<?php echo esc_attr(BWSMTP_OPTIONS_KEY); ?>[user]" value="<?php echo esc_attr($options['user']); ?>" class="regular-text" autocomplete="off" placeholder="<?php esc_attr_e('e.g., you@your-domain.com or apikey', 'beeleewe-smtp'); ?>" <?php disabled($is_constant); ?>>
    <p class="description"><?php esc_html_e('SMTP login. Usually your full email address, but some providers use an API key name or account ID. Leave empty (with empty password) for servers that need no authentication.', 'beeleewe-smtp'); ?><?php bwsmtp_const_note('BWSMTP_USER', $is_wizard); ?></p>
<?php
}

function bwsmtp_field_password_html($is_wizard = false)
{
    $options         = (array) get_option(BWSMTP_OPTIONS_KEY, []);
    $is_constant     = defined('BWSMTP_PASSWORD');
    $has_db_password = !empty($options['password']);
    $disabled        = $is_constant && !$is_wizard;
?>
    <input type="password" id="bwsmtp_password" name="<?php echo esc_attr(BWSMTP_OPTIONS_KEY); ?>[password]" value="" class="regular-text" autocomplete="new-password" <?php disabled($disabled); ?>>
    <?php if ($disabled) : ?>
        <p class="description"><em><?php printf(esc_html__('Defined in wp-config.php (%s).', 'beeleewe-smtp'), '<code>BWSMTP_PASSWORD</code>'); ?></em></p>
    <?php elseif ($has_db_password && !$is_wizard) : ?>
        <p class="description"><?php esc_html_e('A password is saved. Leave this field empty to keep it, or type a new password to change it.', 'beeleewe-smtp'); ?></p>
        <label><input type="checkbox" name="<?php echo esc_attr(BWSMTP_OPTIONS_KEY); ?>[clear_password]" value="1"> <?php esc_html_e('Remove the saved password', 'beeleewe-smtp'); ?></label>
    <?php else : ?>
        <p class="description"><?php esc_html_e('Enter the password for the SMTP user.', 'beeleewe-smtp'); ?></p>
    <?php endif; ?>
<?php
}

function bwsmtp_field_from_email_html($is_wizard = false)
{
    $options     = bwsmtp_form_options($is_wizard);
    $is_constant = defined('BWSMTP_FROM_EMAIL') && !$is_wizard;
?>
    <input type="email" id="bwsmtp_from_email" name="<?php echo esc_attr(BWSMTP_OPTIONS_KEY); ?>[from_email]" value="<?php echo esc_attr($options['from_email']); ?>" class="regular-text" placeholder="<?php esc_attr_e('e.g., no-reply@your-domain.com', 'beeleewe-smtp'); ?>" <?php disabled($is_constant); ?>>
    <p class="description"><?php esc_html_e('Most SMTP servers only accept mail from an address that belongs to the authenticated account or domain. Leave empty to keep the WordPress default.', 'beeleewe-smtp'); ?><?php bwsmtp_const_note('BWSMTP_FROM_EMAIL', $is_wizard); ?></p>
<?php
}

function bwsmtp_field_from_name_html($is_wizard = false)
{
    $options     = bwsmtp_form_options($is_wizard);
    $is_constant = defined('BWSMTP_FROM_NAME') && !$is_wizard;
?>
    <input type="text" id="bwsmtp_from_name" name="<?php echo esc_attr(BWSMTP_OPTIONS_KEY); ?>[from_name]" value="<?php echo esc_attr($options['from_name']); ?>" class="regular-text" placeholder="<?php echo esc_attr(get_bloginfo('name')); ?>" <?php disabled($is_constant); ?>>
    <p class="description"><?php esc_html_e('Sender name shown to recipients. Leave empty to keep the WordPress default.', 'beeleewe-smtp'); ?><?php bwsmtp_const_note('BWSMTP_FROM_NAME', $is_wizard); ?></p>
<?php
}

function bwsmtp_field_force_from_html($is_wizard = false)
{
    $options     = bwsmtp_get_effective_options();
    $is_constant = defined('BWSMTP_FORCE_FROM');
?>
    <input type="hidden" name="<?php echo esc_attr(BWSMTP_OPTIONS_KEY); ?>[force_from]" value="0">
    <label><input type="checkbox" name="<?php echo esc_attr(BWSMTP_OPTIONS_KEY); ?>[force_from]" value="1" <?php checked(!empty($options['force_from'])); ?> <?php disabled($is_constant); ?>> <?php esc_html_e('Always use the From Email above, even when a plugin sets its own', 'beeleewe-smtp'); ?></label>
    <p class="description"><?php esc_html_e('Recommended for contact forms: the original sender address is moved to Reply-To so replies still reach the visitor.', 'beeleewe-smtp'); ?><?php bwsmtp_const_note('BWSMTP_FORCE_FROM', false); ?></p>
<?php
}

function bwsmtp_field_port_html($is_wizard = false)
{
    $options     = bwsmtp_get_effective_options();
    $is_constant = defined('BWSMTP_PORT');
?>
    <input type="number" min="1" max="65535" id="bwsmtp_port" name="<?php echo esc_attr(BWSMTP_OPTIONS_KEY); ?>[port]" value="<?php echo esc_attr($options['port']); ?>" class="small-text" <?php disabled($is_constant); ?>>
    <p class="description"><?php esc_html_e('Optional. Overrides the port of the selected connection type (for example 2525).', 'beeleewe-smtp'); ?><?php bwsmtp_const_note('BWSMTP_PORT', false); ?></p>
<?php
}

function bwsmtp_field_timeout_html($is_wizard = false)
{
    $options     = bwsmtp_get_effective_options();
    $is_constant = defined('BWSMTP_TIMEOUT');
?>
    <input type="number" min="5" max="120" id="bwsmtp_timeout" name="<?php echo esc_attr(BWSMTP_OPTIONS_KEY); ?>[timeout]" value="<?php echo esc_attr($options['timeout']); ?>" class="small-text" <?php disabled($is_constant); ?>>
    <p class="description"><?php esc_html_e('How long to wait for the SMTP server (5-120). A low value stops checkout and form submissions from hanging when the server is down.', 'beeleewe-smtp'); ?><?php bwsmtp_const_note('BWSMTP_TIMEOUT', false); ?></p>
<?php
}

function bwsmtp_field_auto_tls_html($is_wizard = false)
{
    $options = bwsmtp_get_effective_options();
?>
    <input type="hidden" name="<?php echo esc_attr(BWSMTP_OPTIONS_KEY); ?>[auto_tls]" value="0">
    <label><input type="checkbox" name="<?php echo esc_attr(BWSMTP_OPTIONS_KEY); ?>[auto_tls]" value="1" <?php checked(!empty($options['auto_tls'])); ?>> <?php esc_html_e('Upgrade to TLS automatically when the server offers it', 'beeleewe-smtp'); ?></label>
    <p class="description"><?php esc_html_e('Turn off only for old servers with a broken or self-signed certificate.', 'beeleewe-smtp'); ?></p>
<?php
}

function bwsmtp_field_charset_html($is_wizard = false)
{
    $options     = bwsmtp_form_options($is_wizard);
    $is_constant = defined('BWSMTP_CHARSET') && !$is_wizard;
    $charsets    = ['UTF-8' => 'UTF-8 (' . __('Recommended', 'beeleewe-smtp') . ')', 'ISO-8859-1' => 'ISO-8859-1'];
?>
    <select id="bwsmtp_charset" name="<?php echo esc_attr(BWSMTP_OPTIONS_KEY); ?>[charset]" <?php disabled($is_constant); ?>>
        <?php foreach ($charsets as $value => $label) : ?>
            <option value="<?php echo esc_attr($value); ?>" <?php selected($options['charset'], $value); ?>><?php echo esc_html($label); ?></option>
        <?php endforeach; ?>
    </select>
    <p class="description"><?php esc_html_e('Character encoding for emails. UTF-8 is standard and usually the best choice.', 'beeleewe-smtp'); ?><?php bwsmtp_const_note('BWSMTP_CHARSET', $is_wizard); ?></p>
<?php
}

function bwsmtp_field_debug_log_html($is_wizard = false)
{
    $options     = bwsmtp_get_effective_options();
    $is_constant = defined('BWSMTP_DEBUG_LOG') && BWSMTP_DEBUG_LOG;
?>
    <input type="hidden" name="<?php echo esc_attr(BWSMTP_OPTIONS_KEY); ?>[debug_log]" value="0">
    <label><input type="checkbox" id="bwsmtp_debug_log" name="<?php echo esc_attr(BWSMTP_OPTIONS_KEY); ?>[debug_log]" value="1" <?php checked(!empty($options['debug_log'])); ?> <?php disabled($is_constant); ?>> <?php esc_html_e('Enable Debug Logging', 'beeleewe-smtp'); ?></label>
    <p class="description">
        <?php esc_html_e('Writes connection details and SMTP errors to the PHP error log. Recipient addresses and subjects are never logged.', 'beeleewe-smtp'); ?><br>
        <?php printf(esc_html__('Enable %s in wp-config.php to collect these messages in wp-content/debug.log.', 'beeleewe-smtp'), '<code>WP_DEBUG_LOG</code>'); ?>
        <?php bwsmtp_const_note('BWSMTP_DEBUG_LOG', false); ?>
    </p>
<?php
}

function bwsmtp_field_test_email_recipient_html()
{
    $recipient = wp_get_current_user()->user_email;
?>
    <input type="email" id="bwsmtp_test_email_recipient" value="<?php echo esc_attr($recipient); ?>" class="regular-text">
    <button type="button" id="bwsmtp-send-test-email" class="button button-secondary"><?php esc_html_e('Send Test', 'beeleewe-smtp'); ?></button>
    <span id="bwsmtp-test-email-spinner" class="spinner"></span>
    <div id="bwsmtp-test-email-notice" style="margin-top: 10px;"></div>
    <p class="description"><?php esc_html_e('Uses the currently saved settings. Save your changes first.', 'beeleewe-smtp'); ?></p>
<?php
}

function bwsmtp_settings_page_html()
{
    if (!current_user_can('manage_options')) {
        wp_die(esc_html__('You do not have sufficient permissions to access this page.', 'beeleewe-smtp'));
    }
?>
    <div class="wrap">
        <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
        <?php settings_errors('bwsmtp_options'); ?>
        <form action="options.php" method="post">
            <?php settings_fields('beeleewe_smtp_settings_group'); ?>
            <?php do_settings_sections(BWSMTP_SETTINGS_SLUG); ?>
            <?php submit_button(__('Save Settings', 'beeleewe-smtp')); ?>
        </form>
    </div>
<?php
}

/** Admin assets (settings page only). */
add_action('admin_enqueue_scripts', function ($hook_suffix) {
    if ('settings_page_' . BWSMTP_SETTINGS_SLUG !== $hook_suffix) {
        return;
    }
    wp_enqueue_script('bwsmtp-admin-script', BWSMTP_PLUGIN_URL . 'assets/admin.js', ['jquery'], BWSMTP_PLUGIN_VERSION, true);
    wp_localize_script('bwsmtp-admin-script', 'bwsmtp_ajax_object', [
        'ajax_url'           => admin_url('admin-ajax.php'),
        'nonce'              => wp_create_nonce('bwsmtp_send_test_email'),
        'sending_text'       => __('Sending...', 'beeleewe-smtp'),
        'error_text'         => __('An error occurred.', 'beeleewe-smtp'),
        'success_text'       => __('Test email sent successfully!', 'beeleewe-smtp'),
        'invalid_email_text' => __('Please enter a valid email address.', 'beeleewe-smtp'),
    ]);
    wp_enqueue_style('bwsmtp-admin-style', BWSMTP_PLUGIN_URL . 'assets/admin.css', [], BWSMTP_PLUGIN_VERSION);
});

/** AJAX: send a test email. */
add_action('wp_ajax_bwsmtp_send_test_email', function () {
    check_ajax_referer('bwsmtp_send_test_email', 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error(__('Permission denied.', 'beeleewe-smtp'), 403);
    }

    $recipient = isset($_POST['recipient']) ? sanitize_email(wp_unslash($_POST['recipient'])) : '';
    if (!is_email($recipient)) {
        wp_send_json_error(__('Invalid recipient email address.', 'beeleewe-smtp'), 400);
    }

    $subject = sprintf(__('Test Email from %s - Beeleewe SMTP', 'beeleewe-smtp'), get_bloginfo('name'));
    $body    = sprintf(
        __("This is a test email sent from your WordPress site (%s) using the Beeleewe SMTP plugin.\n\nIf you received this email, your SMTP settings are configured correctly.\n\nPlugin Version: %s\nWordPress Version: %s\nPHP Version: %s", 'beeleewe-smtp'),
        home_url(),
        BWSMTP_PLUGIN_VERSION,
        get_bloginfo('version'),
        phpversion()
    );

    $mail_error = null;
    $capture    = function (WP_Error $wp_error) use (&$mail_error) {
        $mail_error = $wp_error;
    };
    add_action('wp_mail_failed', $capture, 10, 1);
    $sent = wp_mail($recipient, $subject, $body);
    remove_action('wp_mail_failed', $capture, 10);

    if ($sent) {
        wp_send_json_success(__('Test email sent successfully!', 'beeleewe-smtp'));
    }

    $message = __('The test email could not be sent.', 'beeleewe-smtp');
    if ($mail_error instanceof WP_Error) {
        $message .= ' ' . $mail_error->get_error_message();
        $options = bwsmtp_get_effective_options();
        if (!empty($options['debug_log'])) {
            $data = $mail_error->get_error_data('wp_mail_failed');
            if (is_array($data) && !empty($data['smtp_error'])) {
                $message .= "\nSMTP: " . $data['smtp_error'];
            }
        } else {
            $message .= ' ' . __('Enable debug logging in settings for more details.', 'beeleewe-smtp');
        }
    } else {
        $message .= ' ' . __('Unknown error. Check your PHP error log and enable debug logging in settings.', 'beeleewe-smtp');
    }
    // Plain text; the admin script inserts it with .text(), never as HTML.
    wp_send_json_error(wp_strip_all_tags($message));
});


/* ==========================================================================
 * PHPMailer configuration
 * ======================================================================== */

add_action('phpmailer_init', 'bwsmtp_configure_phpmailer', 1);

function bwsmtp_configure_phpmailer(PHPMailer $phpmailer)
{
    $options = bwsmtp_get_effective_options();
    $debug   = !empty($options['debug_log']);
    $host    = trim((string) $options['host']);
    $user    = (string) $options['user'];

    if ($host === '') {
        if ($debug && get_option(BWSMTP_OPTIONS_KEY) !== false) {
            error_log('Beeleewe SMTP Debug: Configuration skipped. Missing Host.');
        }
        return;
    }

    $secret   = bwsmtp_get_password();
    $password = $secret['value'];
    if ($secret['error'] !== null) {
        // Fail loudly instead of silently falling back to PHP mail().
        bwsmtp_record_error($secret['error']);
        if ($debug) {
            error_log('Beeleewe SMTP Error: ' . $secret['error']);
        }
    }

    list($port, $encryption) = bwsmtp_resolve_transport($options);

    try {
        $phpmailer->isSMTP();
        $phpmailer->Host        = $host;
        $phpmailer->Port        = $port;
        $phpmailer->CharSet     = $options['charset'];
        $phpmailer->Timeout     = $options['timeout'];
        $phpmailer->SMTPAutoTLS = !empty($options['auto_tls']);

        $use_auth = ($user !== '' && $password !== null && $password !== '');
        $phpmailer->SMTPAuth = $use_auth;
        if ($use_auth) {
            $phpmailer->Username = $user;
            $phpmailer->Password = $password;
        }

        if ($encryption === 'tls') {
            $phpmailer->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        } elseif ($encryption === 'ssl') {
            $phpmailer->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        } else {
            $phpmailer->SMTPSecure = '';
        }

        if ($debug) {
            error_log(sprintf(
                'Beeleewe SMTP Debug: Configuring PHPMailer. Host=%s, Port=%d, Auth=%s, Secure=%s, Timeout=%d, Charset=%s',
                $host,
                $phpmailer->Port,
                $use_auth ? 'Yes' : 'No',
                $phpmailer->SMTPSecure === '' ? 'none' : $phpmailer->SMTPSecure,
                $phpmailer->Timeout,
                $options['charset']
            ));
        }
    } catch (\Exception $e) {
        if ($debug) {
            error_log('Beeleewe SMTP Config Exception: ' . $e->getMessage());
        }
    }
}

/** Force the configured From address even when a plugin passed its own From header. */
add_action('phpmailer_init', function (PHPMailer $phpmailer) {
    $options = bwsmtp_get_effective_options();
    if (empty($options['force_from']) || !is_email($options['from_email'])) {
        return;
    }
    try {
        $original = $phpmailer->From;
        $name     = ($options['from_name'] !== '') ? $options['from_name'] : $phpmailer->FromName;
        if ($original !== '' && strcasecmp($original, $options['from_email']) !== 0 && !$phpmailer->getReplyToAddresses()) {
            $phpmailer->addReplyTo($original, $phpmailer->FromName);
        }
        $phpmailer->setFrom($options['from_email'], $name, false);
    } catch (\Exception $e) {
        if (!empty($options['debug_log'])) {
            error_log('Beeleewe SMTP Force-From Exception: ' . $e->getMessage());
        }
    }
}, 99);

/** Replace the WordPress default sender (wordpress@domain / "WordPress") only. */
add_filter('wp_mail_from', function ($email) {
    $options = bwsmtp_get_effective_options();
    if (is_email($options['from_email']) && strpos((string) $email, 'wordpress@') === 0) {
        return $options['from_email'];
    }
    return $email;
}, 99);

add_filter('wp_mail_from_name', function ($name) {
    $options = bwsmtp_get_effective_options();
    if ($options['from_name'] !== '' && $name === 'WordPress') {
        return $options['from_name'];
    }
    return $name;
}, 99);


/* ==========================================================================
 * Logging / error capture
 * ======================================================================== */

add_action('wp_mail_succeeded', function ($mail_data) {
    if (get_option(BWSMTP_LAST_ERROR_OPTION, false) !== false) {
        delete_option(BWSMTP_LAST_ERROR_OPTION);
    }
    $options = bwsmtp_get_effective_options();
    if (!empty($options['debug_log'])) {
        $count = (isset($mail_data['to']) && is_array($mail_data['to'])) ? count($mail_data['to']) : 1;
        error_log('Beeleewe SMTP Debug: Email sent successfully. Recipients: ' . $count);
    }
}, 10, 1);

add_action('wp_mail_failed', function (WP_Error $wp_error) {
    $message = $wp_error->get_error_message();
    $data    = $wp_error->get_error_data('wp_mail_failed');
    bwsmtp_record_error($message);

    $options = bwsmtp_get_effective_options();
    if (!empty($options['debug_log'])) {
        $log = "Beeleewe SMTP Mail Error:\nCode: " . $wp_error->get_error_code() . "\nMessage: " . $message . "\n";
        if (is_array($data)) {
            if (isset($data['phpmailer_exception_code'])) $log .= 'PHPMailer Code: ' . $data['phpmailer_exception_code'] . "\n";
            if (!empty($data['smtp_error']))               $log .= 'SMTP Error: ' . $data['smtp_error'] . "\n";
            if (!empty($data['smtp_code']))                $log .= 'SMTP Code: ' . $data['smtp_code'] . "\n";
        }
        error_log($log); // Recipient and subject are intentionally not logged.
    }
}, 10, 1);


/* ==========================================================================
 * Plugin meta links
 * ======================================================================== */

add_filter('plugin_action_links_' . plugin_basename(BWSMTP_PLUGIN_FILE), function ($links) {
    array_unshift($links, '<a href="' . esc_url(admin_url('options-general.php?page=' . BWSMTP_SETTINGS_SLUG)) . '">' . esc_html__('Settings', 'beeleewe-smtp') . '</a>');
    return $links;
});
