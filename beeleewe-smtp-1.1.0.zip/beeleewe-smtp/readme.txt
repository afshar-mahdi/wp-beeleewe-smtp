=== Beeleewe SMTP ===
Contributors: beeleewe
Tags: smtp, email, mail, phpmailer, wp_mail
Requires at least: 5.5
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.1.0
License: GPL v2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Send WordPress email through your own SMTP server using PHPMailer, with encrypted password storage, From-address control, a setup wizard and a built-in test tool.

== Description ==

Beeleewe SMTP configures the default WordPress mailer (`wp_mail`) to send through your SMTP server, which improves deliverability for order emails, password resets and contact forms.

**Features**

* Setup wizard on first activation.
* Encrypted password storage (authenticated encryption, key derived from your `wp-config.php` salts), or keep the password out of the database entirely with a `wp-config.php` constant.
* From Email / From Name settings, with an optional "Force From" mode that moves the original sender to Reply-To (ideal for contact forms).
* TLS/587, SSL/465 or unencrypted/25, plus an optional custom port.
* Connection timeout setting so a down mail server cannot freeze checkout or form submissions.
* Username can be any string (API keys and account IDs work), or empty for relays without authentication.
* Test email button, admin notice for the last sending error, optional debug logging.
* Every setting can be fixed in `wp-config.php` (see below).
* Removes all of its data when the plugin is deleted.

**Password security options**

1. **Constant in wp-config.php (most secure):** `define('BWSMTP_PASSWORD', 'your_password');` keeps the password out of the database.
2. **Encrypted in the database:** the password is encrypted with a key derived from the salts in `wp-config.php`. A database leak alone does not expose it. If you change those salts or move the database to a site with different salts, enter the password again.
3. **Plain text (only when the server cannot encrypt):** the settings page warns you.

**wp-config.php constants (all optional)**

`BWSMTP_HOST`, `BWSMTP_USER`, `BWSMTP_PASSWORD`, `BWSMTP_CONNECTION_TYPE` (`tls_587`, `ssl_465`, `none_25`), `BWSMTP_PORT`, `BWSMTP_CHARSET`, `BWSMTP_FROM_EMAIL`, `BWSMTP_FROM_NAME`, `BWSMTP_FORCE_FROM` (true/false), `BWSMTP_TIMEOUT` (5-120), `BWSMTP_DEBUG_LOG` (true).

== Installation ==

1. Upload the `beeleewe-smtp` folder to `/wp-content/plugins/`.
2. Activate the plugin. You are redirected to the setup wizard.
3. Follow the wizard, or go to Settings > Beeleewe SMTP.
4. Use "Send Test" on the settings page to verify.

== Frequently Asked Questions ==

= My emails are accepted by the SMTP server but never arrive =

Set a From Email that belongs to your authenticated account or domain, and make sure SPF/DKIM are set up for that domain. Many servers reject or spam-flag the default `wordpress@yourdomain` address.

= The password field is empty after saving. Did it get deleted? =

No. The field is always shown empty for privacy. Leave it empty to keep the saved password, type a new one to change it, or tick "Remove the saved password" to clear it.

= I see "The saved SMTP password could not be decrypted" =

The `AUTH_KEY` / `AUTH_SALT` values in `wp-config.php` changed, or the database was copied to a site with different salts. Enter the password again and save.

= Why does a contact form email show my From Email instead of the visitor? =

That is "Force From". The visitor's address is added as Reply-To, so replying still reaches them. Turn the option off if you want the plugin's own From address to be used.

= Where is the debug log? =

Enable Debug Logging in the plugin and `define('WP_DEBUG_LOG', true);` in `wp-config.php`. Messages appear in `wp-content/debug.log`. Recipient addresses and subjects are never written to the log.

= Does it support OAuth (Gmail / Microsoft 365)? =

Not yet. Use an app password or your provider's SMTP relay credentials.

== Changelog ==

= 1.1.0 (2026-11-16) =
* Fixed: saving the settings page erased the saved SMTP password when the password field was left empty.
* Fixed: deactivating and reactivating the plugin deleted the encryption key and made the saved password unreadable.
* Fixed: wizard corrupted passwords containing quotes or backslashes (missing unslash).
* Fixed: SMTP username no longer has to be an email address (SendGrid, Amazon SES, etc.). Username and password may both be empty for open relays.
* Security: password encryption now uses authenticated encryption (libsodium secretbox, or AES-256-GCM) with a key derived from wp-config.php salts instead of a key stored next to the data. Existing passwords are migrated automatically.
* Security: admin script no longer inserts server error text as HTML.
* Security: debug log no longer writes recipient addresses or subjects.
* Security: all plugin data (including the password) is removed on uninstall.
* New: From Email, From Name and "Force From" (original sender moved to Reply-To).
* New: connection timeout (default 15 s; PHPMailer's default is 300 s), custom port, opportunistic-TLS switch.
* New: admin notice showing the last mail error; visible error instead of silent fallback when the password cannot be decrypted.
* New: wp-config.php constants BWSMTP_PORT, BWSMTP_FROM_EMAIL, BWSMTP_FROM_NAME, BWSMTP_FORCE_FROM, BWSMTP_TIMEOUT.
* New: option to remove the saved password; wizard keeps typed values after a validation error.
* Improved: translations are now loaded (load_plugin_textdomain); updated .pot file.
* Improved: wizard no longer hijacks bulk activation or re-runs on re-activation of a configured site; direct visits to late wizard steps restart cleanly.
* Improved: options are no longer autoloaded; no more mbstring dependency; removed unused code.
* Changed: minimum WordPress is now 5.5 (namespaced PHPMailer) and minimum PHP 7.4.

= 1.0.0 (2025-04-13) =
* Initial release.

== Upgrade Notice ==

= 1.1.0 =
Fixes password loss on save and on re-activation, adds From address control and a connection timeout. Passwords are migrated automatically to a stronger encryption format. Requires WordPress 5.5+ and PHP 7.4+.
