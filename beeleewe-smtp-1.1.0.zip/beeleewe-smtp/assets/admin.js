/**
 * Beeleewe SMTP Admin Script
 */
(function ($) {
  "use strict";

  $(function () {
    var $button = $("#bwsmtp-send-test-email");
    var $recipientField = $("#bwsmtp_test_email_recipient");
    var $spinner = $("#bwsmtp-test-email-spinner");
    var $noticeDiv = $("#bwsmtp-test-email-notice");

    // Server/SMTP messages are untrusted text: always insert with .text(), never .html().
    function showNotice(type, message) {
      var $p = $("<p>").text(message);
      var $notice = $("<div>")
        .addClass("notice inline notice-" + type)
        .append($p);
      $noticeDiv.empty().append($notice).show();
    }

    // Pressing Enter in the test field must not submit the settings form.
    $recipientField.on("keydown", function (e) {
      if (e.key === "Enter") {
        e.preventDefault();
        $button.trigger("click");
      }
    });

    $button.on("click", function (e) {
      e.preventDefault();

      var recipient = $.trim($recipientField.val());

      if (!recipient || !/^\S+@\S+\.\S+$/.test(recipient)) {
        showNotice("error", bwsmtp_ajax_object.invalid_email_text);
        return;
      }

      $button.prop("disabled", true);
      $spinner.addClass("is-active");
      $noticeDiv.empty().hide();

      $.ajax({
        url: bwsmtp_ajax_object.ajax_url,
        type: "POST",
        data: {
          action: "bwsmtp_send_test_email",
          nonce: bwsmtp_ajax_object.nonce,
          recipient: recipient,
        },
        dataType: "json",
      })
        .done(function (response) {
          if (response && response.success) {
            showNotice(
              "success",
              typeof response.data === "string" && response.data
                ? response.data
                : bwsmtp_ajax_object.success_text
            );
          } else {
            showNotice(
              "error",
              response && typeof response.data === "string" && response.data
                ? response.data
                : bwsmtp_ajax_object.error_text
            );
          }
        })
        .fail(function (jqXHR) {
          var msg = bwsmtp_ajax_object.error_text;
          if (
            jqXHR.responseJSON &&
            typeof jqXHR.responseJSON.data === "string" &&
            jqXHR.responseJSON.data
          ) {
            msg = jqXHR.responseJSON.data;
          }
          showNotice("error", msg);
        })
        .always(function () {
          $button.prop("disabled", false);
          $spinner.removeClass("is-active");
        });
    });
  });
})(jQuery);
